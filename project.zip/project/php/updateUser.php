<?php
$id = $_GET["id"];
include "conn.php";

$re = $db->query("SELECT * FROM login WHERE id = '$id'");
echo "<form method='post' action='updateUser.php'>";

if($re->num_rows > 0)
{
while($row = $re->fetch_assoc())
{
echo "<table>
<tr>
<td>Name: </td>
<td><input type='text' name='name' value=".$row['name']."></td>

<tr>
<td>Surname:</td>
<td><input type='text' name='surname' value=".$row['surname']."></td>
<input type='hidden' name='id' value=".$id.">
</tr>

<tr>
<td>
</td>
<td><input type='submit' name='update' value='Update'>
</table>
</form>";
}
}
else
{
echo "No Data";
echo $db->error;
}



if(isset($_POST['update']))
{
$name = $_POST['name'];
$surname = $_POST['surname'];
$id = $_POST['id'];

$res = $db->query("Update login SET name='$name', surname='$surname' WHERE id='$id'");

if ($res)
{
echo"Your update was successfully made";
header:"location:adminRead.php";
}
else
{
echo $db->error;//Used to locate where the error message is in the code above
}
}