<?php
echo "<html>
	<head>
	<title>Login | Register</title>
	<style>
		body{
	margin: 0;
	padding: 0;
	width: 100%;
	background-color: white;
}

header{
	width: 100%;
	height: 100px;;
}

#my-header-item{
	width: 100%;
	height: 100%;
	position: relative;
}

.header-content-one{
	width: 25%;
	left: 0%;
	position: absolute;
	color: #17c;
	padding-top: 20px;
	font-family: Comic Sans MS;
	font-size: 40px;
}

.header-content-one a{
	text-decoration: none;
	color: #17c;
}

.header-content-two{
	width: 50%;
	height: 100%;
	left: 25%;
	position: absolute;
}

.header-content-three{
	width: 25%;
	height: 100%;
	left: 75%;
	position: absolute;
	font-family: Comic Sans MS;
	font-size: 15px;
	color: #17c;
	padding-top: 40px;
}

.content-three-sub{
	width: 35%;
	height: 25%;
	background-color: #17c;
	color: white;
	border: 2px solid #17c;
	border-radius: 10%;
}

.content-three-sub button{
	width: 100%;
	height: 100%;
	background-color:  white;
	color: #17c;
	border: 0;
}

.content-three-sub button:hover{
	cursor: pointer;
}

#branding{
	width: 100%;
	height: 400px;
	position: relative;
	background-color: white;
}

.description-item{
	width: 25%;
	height: 100%;
	position: absolute;
	left: 0;
	padding: 5px;
	padding-top: 30px;
	padding-left: 30px;
}

.description-item button{
	width: 35%;
	height: 40PX;
	background-color: #ffffff;
	color: white;
	border: 2px solid #17c;
	color: #17c;
	border-radius: 10%;
	font-family: arial black;
}

.description-item button:hover{
	cursor: pointer;
	background-color: #17c;
	color: white;
	text-decoration: underline;
}

.slideshow-item{
	left: 30%;
	width: 50%;
	height: 100%;
	position: absolute;
	
	background-size: cover;
	background-size: 100% 100%;
	display: block;
}

.top-display-item{
	width: 100%;
	height: 200px;
	position: relative;
	padding: 0;
}

.bottom-display-item{
	width: 100%;
	height: 200px;
	padding: 0;
	position: relative;
}

.display-one{
	left: 0;
	width: 50%;
	height: 100%;
	position: absolute;
}

.display-one img{
	width: 100%;
	height: 100%;

}

#branding img {
    animation: rotate 5s infinite;
}

@keyframes rotate {
    100% {
        transform: rotateY(360deg);
    }
}

.display-two{
	left: 50%;
	width: 50%;
	height: 100%;
	position: absolute;
}

.display-two img{
	width: 100%;
	height: 100%;
}

.display-three{
	left: 0;
	width: 50%;
	height: 100%;
	position: absolute;
}

.display-three img{
	width: 100%;
	height: 100%;
}

.display-four{
	left: 50%;
	width: 50%;
	height: 100%;
	position: absolute;
}

.display-four img{
	width: 100%;
	height: 100%;
}

.info-guide-item{
	left: 80%;
	width: 20%;
	height: 100%;
	position: absolute;
}

.body-div-item{
	width: 100%;
	height: 400px;
	background-color: white;

	padding-top: 47px;
}

.login-box-item{
	left: 35%;
	width: 30%;
	height: 360px;
	background-color: #17c;
	
	position: absolute;
}

.login-table td{
	padding-top: 30px;
}

.login-table input{
	border-radius: 5%;
	border: 3px solid #17c;
}

.login-box-item a{
	text-decoration: none;
	color: white;
}

.login-box-item a:hover{
	font-size: 24px;
	font-weight: bolder;
	color: black;
}

.admin-table td{
	padding-top: 10px;
}

#nav-bar{
	position: top;
	margin-left: 25%;
}
#nav-bar >ul li{
	float: left;
	width: 15%;
	height: 40px;
	background-color: 	#4B0082;
	line-height: 40px;
	text-align: center;
	font-size: 20px;
	margin-right: 2px;
	list-style-type: none;
	border: 3px solid black;
	border-radius: 5%;
}

#nav-bar >ul li a{
	text-decoration: none;
	color: white;
	display: block;
	background-color: white;
	color: black; 
}

#nav-bar >ul li a:hover{
	background-color: #17c;
	color: white;

}

#nav-bar >ul li ul li{
	display: none;
}

#nav-bar >ul li:hover  ul li{
	display: block;
	z-index:1000;
}

.my-nav-bar{
	width: 100%;
	height: 60px;
}

#emp-nav-bar ul li{
	position: absolute;
	left: 40%;
	width: 20%;
	height: 40px;
	background-color: #fff;
	line-height: 40px;
	text-align: center;
	font-size: 20px;
	margin-right: 2px;
	list-style-type: none;
	border: 3px solid black;
	border-radius: 5%;
	}

#emp-nav-bar >ul li a{
	text-decoration: none;
	color: white;
	display: block;
	background-color: white;
	color: black;
} 

#emp-nav-bar ul li a:hover{
	background-color: #17c;
	color: white;
}

#emp-nav-bar >ul li ul li{
	display: none;
}

#emp-nav-bar >ul li:hover  ul li{
	display: block;
	z-index:1000;
}
.adminView-table{
	width: 80%;
	height: 180px;
	border: 3px solid red;
	left: 10%;
	position: absolute;
	padding-bottom: -50px;
}

#cvr-img{
	width: 180px;
	height: 300px;
	align-content: center;
	background-color: white;
	display: inline-table;
	margin-right: 10px;
	margin-left: 25px;
	margin-bottom: 10px;
	border:4px solid black;
	position: relative;
}

#cvr-user{
	width: 290px;
	height: 130px;
	align-content: center;
	background-color: white;
	display: inline-table;
	margin-right: 10px;
	margin-left: 25px;
	margin-bottom: 10px;
	padding: 0;
	border:4px solid black;
	position: relative;
}

.cvr-table td{
	width: auto;
	height: auto;
}
	</style>
	</head>
	<body> 
	<header class='login-header'>
		<div id='my-header-item'>
			<div class='header-content-one'><center><b><i>Portable4U</i></b></center></div>
			<div class='header-content-two'>
			</div>
			
		</div>
	</header>
		<div class='body-div-item'>
			<div class='login-box-item'>
				<form action='passthru.php' method='POST'>
					<center><table class='login-table'>
						<tr>
							<td>E-mail :</td>
							<td><input style='text-align:center' type='text' name='email' placeholder='Enter E-mail...'></td>
						</tr>
						<tr>
							<td>Password :</td>
							<td><input style='text-align:center' type='password' name='password' placeholder='Enter Password...'</td>
						</tr>
						<tr>
							<td></td>
							<td style='padding-left:25px'><input style='background-color:#17c;color:white;border:0;width:60px;height:25px' type='submit' name='submit' value='Login'></td>
						</tr>
					</table></center>
				</form>
				<br /><center><b>OR</b></center><br >
				<center><h4><a href='newReg.php'>Register As New User</a></h4></center>
			<div>
		</div>
	
	</body>
	</html>";


?>