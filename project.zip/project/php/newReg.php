<?php
echo "<html>
	<head>
	<title>Registration | New USer</title>
	<link type='text/css' rel='stylesheet' href='../login.css'>
	</head>
	<body>
	<header class='login-header'>
		<div id='my-header-item'>
			<div class='header-content-one'><center><b><i>MyStore</i></b></center></div>
			<div class='header-content-two'>
			</div>
			<div class='header-content-three'>
				<div class='content-three-sub'><center><a href='php/logReg.php'><button>Not Signed In</button></a></center></div>
			</div>
		</div>
	</header>

	<div class='body-div-item'>
			<div class='login-box-item'>
				<form action='registration.php' method='POST'>
					<center><table class='login-table'>
						<tr>
							<td>E-mail :</td>
							<td><input style='text-align:center' type='text' name='email' placeholder='Enter E-mail...'></td>
						</tr>
						<tr>
							<td>Name :</td>
							<td><input style='text-align:center' type='text' name='name' placeholder='Enter Name...'</td>
						</tr>
						<tr>
							<td>Surname :</td>
							<td><input style='text-align:center' type='text' name='surname' placeholder='Enter...'></td>
						</tr>
						<tr>
							<td>Password :</td>
							<td><input style='text-align:center' type='password' name='password' placeholder='Enter Password...'</td>
						</tr>
						<tr>
							<td></td>
							<td style='padding-left:25px'><input style='background-color:#3DC4B6;color:white;border:0;width:60px;height:25px' type='submit' name='submit' value='Register'></td>
						</tr>
					</table></center>
				</form>
			<div>
	</div>
	

	</body>
	</html>";


?>