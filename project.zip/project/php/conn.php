<?php 
	$db = new mysqli('localhost','root','','project');
	if(!$db)
	{
		die("Connnetion failed" .mysqli_connect_error());
	}
 ?>