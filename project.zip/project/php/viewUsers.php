<?php 
echo "<title>Admin Read</title>
<link rel='stylesheet' type='text/css' href='../login.css'>
</head>
<body style='background-color:#3DC4B6'>
<header style='background-color:#fff'>
		<div id='my-header-item'>
			<div class='header-content-one'><center><b><i>MyStore</i></b></center></div>
			<div class='header-content-two'></div>
			<div class='header-content-three'>
				<div class='content-three-sub'><center><button>Admin</button></center></div>
			</div>
		</div>
	</header>
		<div id='nav-bar'>
		<ul>
			<li><a href='admin.php'>Upload Data</a></li>
			<li><a href='adminRead.php'>View Data</a></li>

			<li><a href='logReg.php'>Login | Register</a></li>

			<li><a href='../index.html'>Home</a>
			</li>
		</ul>
		</div>";

include "conn.php";

$res = $db->query("SELECT * FROM login ");

echo "<form action='updateUser.php' method='POST'> ";

$val = "";

if ($res ->num_rows > 0)
{
	while($row = $res->fetch_assoc())
	{
	echo "<div id='cvr-user'>";
	echo "<table class='cvr-table'>
		<tr>
		<td>Name : ".$row['name']."</td>
		</tr>
		<tr>
			<td>Surname : ".$row['surname']."</td>
		</tr>
		<tr>
			<td>E-mail : ".$row['email']."</td>
		</tr>
		<tr>
			<td>Password : ".$row['password']."</td>
		</tr>

		<tr>
			<td><a href='updateUser.php?id=".$row['id']."'>Edit</a></td><td><a href='deleteUser.php?id=".$row['id']."'>Delete</a></td>
		</tr>

	</table>
	</form>";
	echo "</div>";


}
}
else {
	echo $db->error;
}

?>