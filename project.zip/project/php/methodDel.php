<?php
$servername="localhost";
$username="root";
$password="";
$dbname="project";

//Create connection
$conn= new mysqli ($servername, $username, $password, $dbname);
//Check connection

if ($conn->connect_error){
	die("connection failed" . $conn->connect_error);
}
else{
	echo "You're connected!!!";
}


//Insert data into database
if(isset($_POST["submit"])){
	$delDate=$_POST["delDate"];
	$methDel=$_POST["methDel"];
	
	$sql = "INSERT INTO meth_delivery (delDate,methDel) VALUES ('".$delDate."','".$methDel."')";
	
	if($conn->query($sql)===TRUE){
	
		echo "New record created successfully";
		echo '<a href="index.php"><button><<<</button></a>';
	}else{
		echo "error: " . $sql . "<br>" . $conn->error;
		echo '<a href= "index.php"><button<<<</button></a>';
	}
}

?>