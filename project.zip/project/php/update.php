<?php
$id = $_GET["id"];
include "conn.php";

$re = $db->query("SELECT * FROM login WHERE id = '$id'");
echo "<form method='post' action='update.php'>";

if($re->num_rows > 0)
{
while($row = $re->fetch_assoc())
{
echo "<table>
<tr>
<td>Name: </td>
<td><input type='text' name='name' value=".$row['name']."></td>
</tr>
<tr>
	<td>Surname :</td>
	<td><input type='text' name='surname' value=".$row['surname']."></td>
</tr>
<tr>
<td>E-mail:</td>
<td><input type='text' name='email' value=".$row['email']."></td>
<input type='hidden' name='id' value=".$id.">
</tr>
<tr>
	<td>Password :</td>
	<td><input type='text' name='password' value=".$row['password']."></td>
</tr>

<tr>
<td>
</td>
<td><input type='submit' name='update' value='Update'>
</table>
</form>";
}
}
else
{
echo "No Data";
echo $db->error;
}



if(isset($_POST['update']))
{
$name = $_POST['name'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$password = $_POST['password'];
$id = $_POST['id'];

$res = $db->query("Update login SET name='$name', surname='$surname', email='$email', password='$password' WHERE id='$id'");

if ($res)
{
echo"Your update was successfully made";
header ("Location:viewUsers.php");
}
else
{
echo $db->error;//Used to locate where the error message is in the code above
}
}