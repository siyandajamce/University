<?php

session_start();
include('db.php');



$status="";
if (isset($_POST['code']) && $_POST['code']!=""){
$code = $_POST['code'];
$result = mysqli_query($con,"SELECT * FROM `produc` WHERE `code`='$code'");
$row = mysqli_fetch_assoc($result);
$name = $row['name'];
$code = $row['code'];
$price = $row['price'];
$image = $row['image'];

$cartArray = array(
	$code=>array(
	'name'=>$name,
	'code'=>$code,
	'price'=>$price,
	'quantity'=>1,
	'image'=>$image)
);

if(empty($_SESSION["shopping_cart"])) {
	$_SESSION["shopping_cart"] = $cartArray;
	$status = "<div class='box'>Product is added to your cart!</div>";
}else{
	$array_keys = array_keys($_SESSION["shopping_cart"]);
	if(in_array($code,$array_keys)) {
		$status = "<div class='box' style='color:red;'>
		Product is already added to your cart!</div>";	
	} else {
	$_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$cartArray);
	$status = "<div class='box'>Product is added to your cart!</div>";
	}

	}
}
?>
<html>
<head>
<title>Demo Simple Shopping Cart using PHP and MySQL - AllPHPTricks.com</title>
<link rel='stylesheet' href='team.css' type='text/css' media='all' />
<style>
.product_wrapper {
  margin: 1em 0;
  text-align: center;
}

.product_wrapper img {
  width: 10vw;
  height: 10vw;
}

.image img {
  object-fit: cover;
}

.image img {
  object-fit: contain;
}
* {
  box-sizing: border-box;
}

.grid-container {
  float: left;
  width: 33.33%;
  padding: 5px;
  align-content: space-around;
}

.product_wrapper::after {
  content: "";
  clear: both;
  display: table;
  align-content: space-around;
}


</style>
</head>
<body>
<header class="cd-section">
	<h1 style="float:top;text-align:left;"><a href="#">Portable4U</a></h1>

		<nav style="float:right;text-align:right;letter-spacing: 2px;">
		
			<a href="team.html">Home</a>
			<a href="home.php">Shop Now</a>			
			
			<a href="FAQ.html">FAQ</a>
			<span class= "dropdown">
			<a href="#">Contact</a>
			<div class="dropdown-content"><a href="ontactInt.html">Contact through internet</a> <a href="contactUs.html">Contact through form</a>
			
			</div>
			</span>
			
		</header>

<div style="width:700px; margin:50 auto;  text-align: left; width: 800px; margin: 0 auto;">


<?php
if(!empty($_SESSION["shopping_cart"])) {
$cart_count = count(array_keys($_SESSION["shopping_cart"]));
?>
<div class="cart_div">
<a href="cart.php"><img src="cart-icon.png" /> Cart<span><?php echo $cart_count; ?></span></a>
</div>
<?php
}

$result = mysqli_query($con,"SELECT * FROM `produc`");
while($row = mysqli_fetch_assoc($result)){
		echo "<div class='grid-container'>
			  <div class='product_wrapper'>
			  <form method='post' action=''>
			  <input type='hidden' name='code' value=".$row['code']." />
			  <div class='image'><img src='".$row['image']."' /></div>
			  <div class='name'>".$row['name']."</div>
		   	  <div class='price'>R".$row['price']."</div>
			   <div class='description'>".$row['description']."</div>
			  <button type='submit' class='buy'>Add to Cart</button>
			  </form>
			  </div>
			  </div>";
        }
mysqli_close($con);
?>

<div style="clear:both;"></div>

<div class="message_box" style="margin:10px 0px;">
<?php echo $status; ?>

</div class='footer'>
<div>
<p>&copy; 2019 Portable4U. All rights reserved.<p>
<p class="pull-right">Designed by <span><a target="_blank" href="http://www.themeum.com">Portable4U</a></span></p>
</div>
</div>
</body>
</html>