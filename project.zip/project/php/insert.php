<?php 
	include "conn.php";
	if(isset($_POST['upload']))
	{
		
		$itemImage = $_FILES['itemImage']['tmp_name'];
        $imgContent = addslashes(file_get_contents($itemImage));
		$itemDesc = $_POST['itemDesc'];
		$itemPrice = $_POST['itemPrice'];
		$itemName = $_POST['itemName'];
		$barcode = $_POST['barcode'];
		$itemGenre = $_POST['itemGenre'];

		$res = $db->query("INSERT INTO produc (itemImage,itemDesc,itemPrice,itemName,barcode,itemGenre) VALUES ('$imgContent','$itemDesc','$itemPrice','$itemName','$barcode','$itemGenre') ");

		if ($res) 
		{
			echo "<javascript>
				alert('Upload Successful!');
			</javascript>";
			header("Location:admin.php");
			echo "<javascript>
				alert('Upload Successful!');
			</javascript>";
		}
		else
		{

			echo "<div id='frm'>Failed!! <br/> Go back to <a href='admin.php'>Admin page</a> </div>";
			echo mysqli_error($db);
		}
		}
		else
		{
			echo "No data received";
		}
	
 ?>