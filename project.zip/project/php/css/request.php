<?php
if(asset($_POST['submit']){
	$msg='Name:'. $_POST['username'] . "\n"
	.'Cellphone:' .$_POST['cellphone'] ."\n"
	mail(example@example.com, 'Sample Contact Us Form', $msg);
	header('location: thankYou.php');
	}else{
		header('location:form.php');
		exit(0)
}
?>