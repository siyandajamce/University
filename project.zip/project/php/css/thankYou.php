<?php
<h1>Thank You</h1>
<p>Thank you for contacting us. You should receive a message shortly. </p>

?>