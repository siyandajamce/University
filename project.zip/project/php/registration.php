<?php
include "conn.php";
if(isset($_POST['submit']))
{
$email = $_POST["email"];
$name = $_POST["name"];
$surname = $_POST["surname"];
$password = $_POST["password"];
//SQL QUERY TO INSERT DATA INSIDE THE DATABASE
$res = $db->query("INSERT INTO login(email,name,surname,password) VALUES('$email','$name','$surname','$password')");
if($res)
{
echo "<script>
		alert('Congratulations.... You have Successfully Logged In');
	</script>";
echo "<script>setTimeout(function() { location.replace('logReg.php')},1000);</script>";	
}
else
{
echo "Data not inserted";
 echo mysqli_error($db);
}
}
else
{
echo "No data recieved";
}