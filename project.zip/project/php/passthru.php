
<?php 
	include "conn.php";
	session_start();
	if(isset($_POST['submit']))
	{
		$email = $_POST['email'];
		$password = $_POST['password'];

		$res = $db->query("SELECT * FROM login WHERE email = '$email' AND password = '$password' ");
		$row = mysqli_fetch_array($res);

	if($row > 0)
	{
		session_start();
		echo "<script>
			alert('Welcome to MyStore :You are now Logged IN');
			window.location.href='../index.html';
			</script>";

		if ($email == 'admin.com') {
			header("Location:admin.php");

			echo '<script language="javascript">';
			echo 'alert("Welcome Admin")';
			echo '</script>';
		}
		elseif ($email == 'employee@mystore.com')
		{
			header("Location:employeeAdd.php");
		}
		else
		{
			header("Location:team.html");
		}
		
	}
	else
	{
			echo "<script>
			alert('Login Fialed! Please try again Or Contact Admin');
			window.location.href='logReg.php';
			</script>";
		
	}
	}


 ?>