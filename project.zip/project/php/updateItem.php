<?php
$id = $_GET["id"];
include "conn.php";

$re = $db->query("SELECT * FROM produc WHERE id = '$id'");
echo "<form method='post' action='updateItem.php' enctype='multipart/form-data'>";

if($re->num_rows > 0)
{
while($row = $re->fetch_assoc())
{
echo "<table>
<tr>
<td>Image: </td>
<td>";
			echo "<link rel='stylesheet' type = 'text/css' href = '../login.css'>";
			
			echo '<img style="height:200;width:200;" src = "data:image/jpeg;base64,'.base64_encode($row['itemImage']).'" alt = "" />'; 
			
			echo "<br/></td>
			<td><center><input type='file' name='itemImage'></center></td>
</tr>
<tr>
	<td>Item Name :</td>
	<td><input type='text' name='itemName' value=".$row['itemName']."></td>
</tr>
<tr>
<td>Item Price:</td>
<td><input type='number' name='itemPrice' value=".$row['itemPrice']."></td>
<input type='hidden' name='id' value=".$id.">
</tr>
<tr>
	<td>Barcode :</td>
	<td><input type='number' name='barcode' value=".$row['barcode']."></td>
</tr>

<tr>
<td>
</td>
<td><input type='submit' name='update' value='Update'>
</table>
</form>";
}
}
else
{
echo "No Data";
echo $db->error;
}



if(isset($_POST['update']))
{
$itemName = $_POST['itemName'];
$itemPrice = $_POST['itemPrice'];
$itemImage = $_POST['itemImage'];
$barcode = $_POST['barcode'];
$itemImage = $_FILES['itemImage']['tmp_name'];
$imgContent = addslashes(file_get_contents($itemImage));
$id = $_POST['id'];

$res = $db->query("Update produc SET itemName='$itemName', itemPrice='$itemPrice', barcode='$barcode', itemImage='$imgContent' WHERE id='$id'");

if ($res)
{
echo"Your update was successfully made";
header ("Location:adminRead.php");
}
else
{
echo $db->error;//Used to locate where the error message is in the code above
}
}